using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Stat {
 
    [SerializeField]
    public int baseValue;

    private List<int> modifiers = new List<int>();

    public int getValue() {
        return baseValue;
    }

    public void addModifier(int modifier) {
        if(modifier != 0) {
            modifiers.Add(modifier);
        }
    }

    public void removeModifier(int modifier) {
        if(modifier != 0) {
            modifiers.Remove(modifier);
        }
    }
}
