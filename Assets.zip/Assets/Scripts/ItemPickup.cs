using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//Run this on all items that you can pickup
public class ItemPickup : MonoBehaviour
{


   private void OnTriggerEnter2D(Collider2D collision) {
        
        PlayerManager manager = collision.GetComponent<PlayerManager>();
        if(manager) {
            manager.PickupItem();
            Destroy(gameObject);
        }
    }
}
